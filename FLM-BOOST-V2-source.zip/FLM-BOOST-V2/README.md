# FLM BOOST V2.0
Android Java project, no root and no Shizuku. Does not overclock CPU or force-stop other applications.

## Build
Upload the CONTENTS of this folder to the root of a GitHub repository, then Actions > Build FLM BOOST APK > Run workflow. Download artifact FLM-BOOST-V2-debug-apk.

Requires Android SDK 35, JDK 17, Gradle 8.7. The package name for FL Studio Mobile may differ across versions; edit MainActivity.java if needed.
