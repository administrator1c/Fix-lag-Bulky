package com.flmboost.app;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Debug;
import android.os.Process;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Locale;

public class MainActivity extends Activity {
    private LinearLayout root;
    private TextView status;
    private final int bg = Color.rgb(9, 12, 24);
    private final int neon = Color.rgb(0, 230, 185);
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(bg);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(30, 48, 30, 30);
        scroll.addView(root);
        setContentView(scroll);
        TextView heading = text("FLM BOOST  V2.0", 28, neon);
        heading.setTypeface(null, Typeface.BOLD);
        root.addView(heading);
        root.addView(text("AUDIO PERFORMANCE • NO ROOT • NO SHIZUKU", 12, Color.LTGRAY));
        status = text("Sẵn sàng tối ưu", 17, Color.WHITE);
        root.addView(status);
        button("⚡ TỐI ƯU & MỞ FL STUDIO MOBILE", () -> { optimize(); launchFlm(); });
        button("🧹 DỌN BỘ NHỚ CỦA FLM BOOST", this::cleanOwnMemory);
        button("📊 KIỂM TRA RAM", this::showMemory);
        button("🔋 MỞ CÀI ĐẶT PIN", () -> openSettings(Settings.ACTION_BATTERY_SAVER_SETTINGS));
        button("📱 MỞ CÀI ĐẶT MÀN HÌNH", () -> openSettings(Settings.ACTION_DISPLAY_SETTINGS));
        button("⚙️ QUẢN LÝ ỨNG DỤNG NỀN", () -> openSettings(Settings.ACTION_APPLICATION_SETTINGS));
        button("🎹 MỞ FL STUDIO MOBILE", this::launchFlm);
        root.addView(text("Lưu ý: Android không cho app thường ép xung CPU, đóng app khác hoặc bảo đảm 60 FPS. Để giảm giật âm thanh, hãy tăng audio buffer trong FL Studio Mobile khi cần.", 13, Color.LTGRAY));
        showMemory();
    }
    private TextView text(String s, int sp, int color) {
        TextView v = new TextView(this);
        v.setText(s); v.setTextSize(sp); v.setTextColor(color);
        v.setPadding(0, 12, 0, 18);
        return v;
    }
    private void button(String title, Runnable task) {
        Button b = new Button(this);
        b.setText(title); b.setTextColor(Color.BLACK); b.setAllCaps(false);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(neon));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, 8, 0, 8);
        root.addView(b, p);
        b.setOnClickListener(v -> task.run());
    }
    private void showMemory() {
        ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo info = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(info);
        double available = info.availMem / 1073741824.0;
        double total = info.totalMem / 1073741824.0;
        status.setText(String.format(Locale.US, "RAM khả dụng: %.2f / %.2f GB", available, total));
    }
    private void cleanOwnMemory() {
        System.gc();
        showMemory();
        Toast.makeText(this, "Đã yêu cầu thu gom bộ nhớ của FLM BOOST", Toast.LENGTH_SHORT).show();
    }
    private void optimize() {
        cleanOwnMemory();
        Toast.makeText(this, "Hãy tắt tiết kiệm pin và đóng thủ công các app nặng", Toast.LENGTH_LONG).show();
    }
    private void openSettings(String action) {
        try { startActivity(new Intent(action)); }
        catch (Exception e) { startActivity(new Intent(Settings.ACTION_SETTINGS)); }
    }
    private void launchFlm() {
        String[] packages = {"com.imageline.FLM", "com.imageline.FLMdemo"};
        for (String pkg : packages) {
            Intent launch = getPackageManager().getLaunchIntentForPackage(pkg);
            if (launch != null) { startActivity(launch); return; }
        }
        Toast.makeText(this, "Không tìm thấy FL Studio Mobile. Hãy kiểm tra ứng dụng đã cài.", Toast.LENGTH_LONG).show();
    }
}
