# FLM BOOST v1.3 — Shizuku FIX LAG

Android 10+ (API 29). Chế độ FIX LAG chỉ buộc dừng **một ứng dụng do người dùng nhập và xác nhận**, thông qua Shizuku đã được cấp quyền. Không tự dừng ứng dụng hệ thống, FL Studio Mobile hoặc Shizuku. Buộc dừng có thể mất dữ liệu chưa lưu và ngắt thông báo; không bảo đảm CPU/RAM 20–30% hoặc hết lag.

## Build
Upload `FLM-BOOST-v1.3-Shizuku-Source.zip` vào gốc repository và thay `.github/workflows/build.yml` bằng file `build-v1.3.yml` đi kèm. Actions -> Build FLM BOOST v1.3 APK -> Artifacts.

## Sử dụng
Khởi động Shizuku trên Android; mở FLM BOOST, cấp quyền; nhập package của app nền không cần thiết và xác nhận dừng. Không dừng app đang có dữ liệu chưa lưu.
