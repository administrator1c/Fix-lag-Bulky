package com.flmboost.lagfix;

import android.app.Activity;
import android.app.AlertDialog;
import android.widget.EditText;
import android.text.InputType;
import java.util.concurrent.TimeUnit;
import android.app.ActivityManager;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.StatFs;
import android.provider.Settings;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.Locale;
import android.content.pm.PackageManager;
import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {
    private LinearLayout content;
    private TextView ramInfo, storageInfo, status, cpuInfo, ecoInfo;
    private boolean ecoMode = false;
    private TextView shizukuInfo;
    private EditText packageInput;
    private static final int SHIZUKU_REQUEST = 501;
    private final Shizuku.OnRequestPermissionResultListener permissionListener = (requestCode, grantResult) -> {
        if (requestCode == SHIZUKU_REQUEST) runOnUiThread(this::refreshShizuku);
    };
    private final int CYAN = Color.rgb(0, 217, 233);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(8,12,22));
        getWindow().setNavigationBarColor(Color.rgb(8,12,22));
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.rgb(8,12,22));
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(22),dp(32),dp(22),dp(30));
        scroll.addView(content);
        setContentView(scroll);

        TextView title = text("FLM BOOST", 32, CYAN, true);
        content.addView(title);
        content.addView(text("LAG FIX  •  PERFORMANCE ASSISTANT", 12, Color.rgb(151,164,190),false));
        space(28);
        content.addView(text("DEVICE STATUS", 14, CYAN,true));
        space(12);
        LinearLayout panel = panel();
        ramInfo = text("RAM: Đang kiểm tra...", 17, Color.WHITE,true);
        storageInfo = text("Bộ nhớ: Đang kiểm tra...", 15, Color.LTGRAY,false);
        panel.addView(ramInfo);
        cpuInfo = text("CPU: Android không cung cấp % CPU toàn hệ thống ổn định cho app thường", 13, Color.LTGRAY,false);
        panel.addView(cpuInfo);
        panel.addView(storageInfo);
        panel.addView(text("Android " + Build.VERSION.RELEASE + "  •  " + Build.MANUFACTURER + " " + Build.MODEL, 13, Color.LTGRAY,false));
        space(22);
        content.addView(text("QUICK BOOST", 14, CYAN,true));
        space(12);
        addButton("⚡  BOOST & REFRESH", () -> boost());
        space(12);
        addButton("♻  BẬT / TẮT ECO MODE", () -> toggleEco());
        space(8);
        ecoInfo = text("ECO MODE: Tắt — không chạy theo dõi liên tục", 13, Color.LTGRAY,false);
        content.addView(ecoInfo);
        space(12);
        addButton("♫  MỞ FL STUDIO MOBILE", () -> launchFLM());
        space(12);
        addButton("⚙  CÀI ĐẶT PIN", () -> openSettings(Settings.ACTION_BATTERY_SAVER_SETTINGS));
        space(12);
        addButton("◉  CÀI ĐẶT ỨNG DỤNG", () -> openSettings(Settings.ACTION_APPLICATION_SETTINGS));
        space(20);
        content.addView(text("SHIZUKU MODE", 14, CYAN, true));
        space(8);
        shizukuInfo = text("Shizuku: Đang kiểm tra...", 14, Color.LTGRAY, false);
        content.addView(shizukuInfo);
        space(8);
        addButton("🔑  KẾT NỐI / CẤP QUYỀN SHIZUKU", () -> requestShizuku());
        space(8);
        addButton("↻  KIỂM TRA SHIZUKU", () -> refreshShizuku());
        space(12);
        content.addView(text("FIX LAG — DỪNG APP NỀN ĐƯỢC CHỌN", 14, CYAN, true));
        content.addView(text("Nhập package của ứng dụng bạn muốn dừng (ví dụ com.example.app). Không dừng FL Studio Mobile hoặc app hệ thống.", 12, Color.LTGRAY, false));
        packageInput = new EditText(this);
        packageInput.setSingleLine(true);
        packageInput.setTextColor(Color.WHITE);
        packageInput.setHintTextColor(Color.GRAY);
        packageInput.setHint("com.example.app");
        packageInput.setInputType(InputType.TYPE_CLASS_TEXT);
        content.addView(packageInput);
        addButton("⚡ FIX LAG — DỪNG APP ĐÃ CHỌN", () -> confirmStop());
        space(20);
        status = text("Sẵn sàng. Hãy đóng ứng dụng không cần thiết trước khi làm nhạc.", 14, Color.rgb(170,185,204),false);
        content.addView(status);
        space(24);
        content.addView(text("Mục tiêu 20–30% CPU/RAM chỉ là tham khảo, không thể ép buộc. ECO MODE giảm hoạt động của chính FLM BOOST; không can thiệp vào ứng dụng khác.", 12, Color.rgb(119,135,156),false));
        refreshStats();
        Shizuku.addRequestPermissionResultListener(permissionListener);
        refreshShizuku();
    }

    @Override protected void onResume() {
        super.onResume();
        if (shizukuInfo != null) refreshShizuku();
    }

    @Override protected void onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permissionListener);
        super.onDestroy();
    }

    private void refreshShizuku() {
        if (shizukuInfo == null) return;
        try {
            if (!Shizuku.pingBinder()) {
                shizukuInfo.setText("Shizuku chưa chạy. Mở Shizuku và khởi động dịch vụ trước.");
            } else if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                shizukuInfo.setText("✓ Shizuku đã kết nối và cấp quyền. Chế độ kiểm tra đã sẵn sàng.");
            } else {
                shizukuInfo.setText("Shizuku đang chạy, cần cấp quyền cho FLM BOOST.");
            }
        } catch (Exception e) {
            shizukuInfo.setText("Không kiểm tra được Shizuku: " + e.getClass().getSimpleName());
        }
    }

    private void requestShizuku() {
        try {
            if (!Shizuku.pingBinder()) {
                status.setText("Hãy cài và chạy Shizuku trước, sau đó quay lại FLM BOOST.");
                refreshShizuku();
                return;
            }
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                status.setText("Đã có quyền Shizuku. Không thay đổi CPU/RAM hệ thống.");
            } else if (Shizuku.shouldShowRequestPermissionRationale()) {
                status.setText("Quyền Shizuku đã bị từ chối. Hãy cấp lại trong ứng dụng Shizuku.");
            } else {
                Shizuku.requestPermission(SHIZUKU_REQUEST);
            }
            refreshShizuku();
        } catch (Exception e) {
            status.setText("Không thể yêu cầu quyền Shizuku: " + e.getMessage());
        }
    }

    private void confirmStop() {
        final String pkg = packageInput.getText().toString().trim();
        if (!pkg.matches("[a-zA-Z][a-zA-Z0-9_]*(\\.[a-zA-Z][a-zA-Z0-9_]*)+")) {
            status.setText("Package không hợp lệ."); return;
        }
        if (pkg.equals(getPackageName()) || pkg.equals("com.imageline.FLM") ||
            pkg.equals("moe.shizuku.privileged.api") || pkg.equals("android") ||
            pkg.startsWith("com.android.") || pkg.startsWith("com.google.android.") ||
            pkg.startsWith("com.samsung.android.") || pkg.startsWith("com.miui.") ||
            pkg.startsWith("com.sec.")) {
            status.setText("Đã chặn ứng dụng hệ thống, FL Studio hoặc Shizuku."); return;
        }
        try {
            android.content.pm.ApplicationInfo info = getPackageManager().getApplicationInfo(pkg, 0);
            if ((info.flags & (android.content.pm.ApplicationInfo.FLAG_SYSTEM | android.content.pm.ApplicationInfo.FLAG_UPDATED_SYSTEM_APP)) != 0) {
                status.setText("Không cho phép dừng ứng dụng hệ thống."); return;
            }
        } catch (PackageManager.NameNotFoundException e) {
            status.setText("Không tìm thấy ứng dụng. Kiểm tra package và quyền hiển thị ứng dụng."); return;
        }
        new AlertDialog.Builder(this)
            .setTitle("Dừng ứng dụng nền?")
            .setMessage("Buộc dừng " + pkg + " có thể làm mất dữ liệu chưa lưu hoặc ngắt thông báo. Chỉ tiếp tục nếu bạn đã lưu công việc.")
            .setNegativeButton("Hủy", null)
            .setPositiveButton("Dừng ứng dụng", (dialog, which) -> stopViaShizuku(pkg))
            .show();
    }

    private void stopViaShizuku(String pkg) {
        try {
            if (!Shizuku.pingBinder() || Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                status.setText("Cần khởi động và cấp quyền Shizuku trước."); return;
            }
        } catch (Exception e) { status.setText("Shizuku chưa sẵn sàng."); return; }
        status.setText("Đang yêu cầu Shizuku dừng " + pkg + "...");
        new Thread(() -> {
            String result;
            try {
                // Package name was validated; no shell interpolation.
                Process process = Shizuku.newProcess(new String[]{"am", "force-stop", pkg}, null, null);
                boolean finished = process.waitFor(8, TimeUnit.SECONDS);
                if (!finished) { process.destroy(); result = "Hết thời gian chờ Shizuku."; }
                else if (process.exitValue() == 0) result = "Đã gửi lệnh dừng " + pkg + ". RAM/CPU không được bảo đảm giảm.";
                else result = "Không thể dừng ứng dụng (mã " + process.exitValue() + ").";
            } catch (Exception | LinkageError e) { result = "Lỗi Shizuku: " + e.getClass().getSimpleName(); }
            final String message = result;
            runOnUiThread(() -> { status.setText(message); refreshStats(); });
        }).start();
    }

    private void toggleEco() {
        ecoMode = !ecoMode;
        ecoInfo.setText(ecoMode ? "ECO MODE: Bật — cập nhật thủ công, không có tác vụ nền" : "ECO MODE: Tắt — không chạy theo dõi liên tục");
        status.setText(ecoMode ? "Đã bật ECO MODE. FLM BOOST không chạy dịch vụ nền." : "Đã tắt ECO MODE.");
    }

    private void boost() {
        refreshStats();
        status.setText("✓ Đã làm mới thông tin. Để giảm giật: đóng app nền, tắt tiết kiệm pin khi cần, và giảm số plugin/track trong FL Studio Mobile.");
        status.setTextColor(CYAN);
    }

    private void refreshStats() {
        ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo info = new ActivityManager.MemoryInfo();
        if (am != null) {
            am.getMemoryInfo(info);
            double usedPercent = 100.0 * (info.totalMem - info.availMem) / info.totalMem;
            ramInfo.setText(String.format(Locale.US,"RAM đang dùng: %.1f%% | Khả dụng: %.1f / %.1f GB", usedPercent, info.availMem/1073741824.0,info.totalMem/1073741824.0));
        }
        try {
            StatFs stat = new StatFs(Environment.getDataDirectory().getPath());
            storageInfo.setText(String.format(Locale.US,"Bộ nhớ trống: %.1f GB",stat.getAvailableBytes()/1073741824.0));
        } catch (Exception e) { storageInfo.setText("Không đọc được bộ nhớ"); }
    }

    private void launchFLM() {
        Intent intent = getPackageManager().getLaunchIntentForPackage("com.imageline.FLM");
        if (intent != null) {
            startActivity(intent);
            status.setText("Đang mở FL Studio Mobile...");
        } else {
            status.setText("Không tìm thấy FL Studio Mobile. Hãy cài ứng dụng hoặc mở thủ công.");
        }
    }
    private void openSettings(String action) {
        try { startActivity(new Intent(action)); }
        catch (Exception e) { startActivity(new Intent(Settings.ACTION_SETTINGS)); }
    }
    private LinearLayout panel() {
        LinearLayout p = new LinearLayout(this);
        p.setOrientation(LinearLayout.VERTICAL);
        p.setPadding(dp(18),dp(16),dp(18),dp(16));
        p.setBackgroundResource(com.flmboost.lagfix.R.drawable.panel);
        content.addView(p);
        return p;
    }
    private TextView text(String value, int size, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(value);
        v.setTextSize(size);
        v.setTextColor(color);
        v.setPadding(0,dp(5),0,dp(5));
        if (bold) v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        return v;
    }
    private void addButton(String value, Runnable action) {
        Button b = new Button(this);
        b.setText(value);
        b.setTextSize(14);
        b.setAllCaps(false);
        b.setTextColor(Color.rgb(8,12,22));
        b.setBackgroundResource(R.drawable.button);
        b.setGravity(Gravity.CENTER);
        b.setOnClickListener(v -> action.run());
        content.addView(b, new LinearLayout.LayoutParams(-1,dp(56)));
    }
    private void space(int h) { View v = new View(this); content.addView(v,new LinearLayout.LayoutParams(1,dp(h))); }
    private int dp(int value) { return (int)(value*getResources().getDisplayMetrics().density+0.5f); }
}
